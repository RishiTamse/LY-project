import os
import numpy as np
import cv2
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split

# Attempt to import TensorFlow and handle missing module error
try:
    import tensorflow as tf
    from tensorflow import keras
    from tensorflow.keras import layers
except ModuleNotFoundError:
    raise ModuleNotFoundError("TensorFlow is not installed. Please install it using 'pip install tensorflow'.")

# Load dataset (Assuming images are stored in "real" and "fake" folders)
image_size = (256, 256)

def load_images_from_folder(folder):
    images = []
    for filename in os.listdir(folder):
        img = cv2.imread(os.path.join(folder, filename))
        if img is not None:
            img = cv2.resize(img, image_size)
            img = img / 255.0  # Normalize
            images.append(img)
    return np.array(images)

real_images = load_images_from_folder("dataset/real")
fake_images = load_images_from_folder("dataset/fake")

# Creating segmentation masks (Assuming binary classification)
real_labels = np.zeros((real_images.shape[0], *image_size, 1))  # Real banknotes mask
fake_labels = np.ones((fake_images.shape[0], *image_size, 1))  # Fake banknotes mask

# Merging dataset
X = np.concatenate((real_images, fake_images), axis=0)
y = np.concatenate((real_labels, fake_labels), axis=0)

# Splitting dataset
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# U-Net Model
inputs = keras.Input(shape=(256, 256, 3))

# Encoder
c1 = layers.Conv2D(64, (3, 3), activation='relu', padding='same')(inputs)
c1 = layers.Conv2D(64, (3, 3), activation='relu', padding='same')(c1)
p1 = layers.MaxPooling2D((2, 2))(c1)

c2 = layers.Conv2D(128, (3, 3), activation='relu', padding='same')(p1)
c2 = layers.Conv2D(128, (3, 3), activation='relu', padding='same')(c2)
p2 = layers.MaxPooling2D((2, 2))(c2)

# Bottleneck
c3 = layers.Conv2D(256, (3, 3), activation='relu', padding='same')(p2)
c3 = layers.Conv2D(256, (3, 3), activation='relu', padding='same')(c3)

# Decoder
u1 = layers.UpSampling2D((2, 2))(c3)
u1 = layers.concatenate([u1, c2])
c4 = layers.Conv2D(128, (3, 3), activation='relu', padding='same')(u1)
c4 = layers.Conv2D(128, (3, 3), activation='relu', padding='same')(c4)

u2 = layers.UpSampling2D((2, 2))(c4)
u2 = layers.concatenate([u2, c1])
c5 = layers.Conv2D(64, (3, 3), activation='relu', padding='same')(u2)
c5 = layers.Conv2D(64, (3, 3), activation='relu', padding='same')(c5)

outputs = layers.Conv2D(1, (1, 1), activation='sigmoid')(c5)

model = keras.Model(inputs, outputs)
model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])

# Training the model
epochs = 10
history = model.fit(X_train, y_train, validation_data=(X_test, y_test), epochs=epochs, batch_size=8)

# Testing the model
def predict_mask(image):
    image = cv2.resize(image, image_size) / 255.0
    image = np.expand_dims(image, axis=0)
    mask = model.predict(image)[0]
    return mask

# Display Results
sample_image = X_test[0]
predicted_mask = predict_mask(sample_image)

plt.figure(figsize=(10, 5))
plt.subplot(1, 2, 1)
plt.imshow(sample_image)
plt.title("Original Image")

plt.subplot(1, 2, 2)
plt.imshow(predicted_mask.squeeze(), cmap='gray')
plt.title("Predicted Mask")
plt.show()
