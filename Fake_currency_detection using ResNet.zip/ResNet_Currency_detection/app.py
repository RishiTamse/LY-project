import tensorflow as tf
import numpy as np
import cv2
import tkinter as tk
from tkinter import filedialog
from PIL import Image, ImageTk

# Load Model
model = tf.keras.models.load_model("model/resnet_model.h5")

# GUI Setup
root = tk.Tk()
root.title("Fake Currency Detector")
root.geometry("500x500")

# Label to show image
image_label = tk.Label(root)
image_label.pack(pady=10)

# Label to show result
result_text = tk.StringVar()
result_label = tk.Label(root, textvariable=result_text, font=("Arial", 14), justify="center")
result_label.pack(pady=10)

# Function to Preprocess & Predict
def predict_currency(img_path):
    IMG_SIZE = 224
    img = cv2.imread(img_path)
    img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    resized_img = cv2.resize(img_rgb, (IMG_SIZE, IMG_SIZE))
    normalized_img = resized_img / 255.0
    input_img = np.expand_dims(normalized_img, axis=0)

    prediction = model.predict(input_img)[0][0]
    confidence = prediction if prediction > 0.5 else 1 - prediction
    confidence_percent = confidence * 100

    if prediction > 0.5:
        result = "Fake Currency Detected! 🚨"
    else:
        result = "Real Currency ✅"

    result += f"\nConfidence: {confidence_percent:.2f}%"
    result_text.set(result)

    # Show selected image
    img_pil = Image.fromarray(resized_img)
    img_tk = ImageTk.PhotoImage(img_pil)
    image_label.config(image=img_tk)
    image_label.image = img_tk  # Keep reference

# Function to select image
def select_image():
    file_path = filedialog.askopenfilename(
        title="Select a Currency Image",
        filetypes=[("Image Files", "*.png;*.jpg;*.jpeg")]
    )
    if file_path:
        predict_currency(file_path)

# Button to open file selection
select_button = tk.Button(root, text="Select Image", command=select_image, font=("Arial", 12), bg="blue", fg="white")
select_button.pack(pady=10)

# Run GUI
root.mainloop()
